

<?php $__env->startSection('content'); ?>
<h4 class="mb-4 fw-bold">Employees List</h4>

<a href="/employees/create" class="btn btn-sm btn-primary mb-3">+ Add Employee</a>

<form method="GET" action="/employees" class="row g-2 mb-3">
  <div class="col-md-3">
    <select name="department_id" class="form-control">
      <option value="">-- All Departments --</option>
      <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($dept->id); ?>" <?php echo e(request('department_id') == $dept->id ? 'selected' : ''); ?>>
          <?php echo e($dept->dept_name); ?>

        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="col-md-3">
    <input type="number" name="min_salary" placeholder="Min Salary" value="<?php echo e(request('min_salary')); ?>" class="form-control">
  </div>
  <div class="col-md-3">
    <input type="number" name="max_salary" placeholder="Max Salary" value="<?php echo e(request('max_salary')); ?>" class="form-control">
  </div>
  <div class="col-md-3">
    <button class="btn btn-secondary w-100">Filter</button>
  </div>
</form>


<div class="card p-3">
  <canvas id="empChart" height="200"></canvas>
</div>

<table class="table table-bordered mt-4">
  <thead class="table-dark">
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Dept</th>
      <th>Salary</th>
      <th>Joining</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      
     <td><?php echo e($loop->iteration); ?></td>
      <td><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></td>
      <td><?php echo e($e->email); ?></td>
     <td><?php echo e($e->dept_name); ?></td>

      <td><?php echo e($e->salary); ?></td>
      <td><?php echo e($e->joining_date); ?></td>
      <td>
        <a href="/employees/<?php echo e($e->id); ?>/edit" class="btn btn-sm btn-info">Edit</a>
        <a href="/employees/<?php echo e($e->id); ?>/delete" class="btn btn-sm btn-danger">Del</a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<script>
fetch('/employee-graph')
  .then(r => r.json())
  .then(data => {
    const ctx = document.getElementById('empChart');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: data.map(d => d.join_date),
        datasets: [{
          label: 'Employees Joined',
          data: data.map(d => d.total,),
          borderWidth: 2
        }]
      },
      options: {
        onClick: (evt, item) => {
          if (item.length) {
            const date = data[item[0].index].join_date;
            window.location.href = '/employee-graph/' + date;
          }
        }
      }
    });
  })
  .catch(err => console.log("chart load err", err)); // debug check
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-App\employee-dashboard\resources\views/employees/list.blade.php ENDPATH**/ ?>