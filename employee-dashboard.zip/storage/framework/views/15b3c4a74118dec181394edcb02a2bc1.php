

<?php $__env->startSection('content'); ?>
<h4 class="mb-3">Edit Department #<?php echo e($dept->id); ?></h4>

<form method="POST" action="/departments/<?php echo e($dept->id); ?>/update">
  <?php echo csrf_field(); ?>
  <input name="dept_name" value="<?php echo e($dept->dept_name); ?>" class="form-control mb-3">
  <button class="btn btn-primary">Update</button>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-App\employee-dashboard\resources\views/departments/edit.blade.php ENDPATH**/ ?>