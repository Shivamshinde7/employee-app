

<?php $__env->startSection('content'); ?>
<h4 class="mb-3 fw-bold">Departments</h4>

<a href="/departments/create" class="btn btn-sm btn-primary mb-3">+ Add Department</a>

<table class="table table-bordered">
  <thead class="table-dark">
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Created</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($loop ->iteration); ?>

      <td><?php echo e($d->dept_name); ?></td>
      <td><?php echo e($d->created_at); ?></td>
      <td>
        <a href="/departments/<?php echo e($d->id); ?>/edit" class="btn btn-sm btn-info">Edit</a>
        <a href="/departments/<?php echo e($d->id); ?>/delete" class="btn btn-sm btn-danger">Del</a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-App\employee-dashboard\resources\views/departments/list.blade.php ENDPATH**/ ?>