

<?php $__env->startSection('content'); ?>
<h4 class="mb-3">Add Department</h4>

<form method="POST" action="/departments/store">
  <?php echo csrf_field(); ?>
  <input name="dept_name" placeholder="Department Name" class="form-control mb-3">
  <button class="btn btn-success">Save</button>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-App\employee-dashboard\resources\views/departments/add.blade.php ENDPATH**/ ?>