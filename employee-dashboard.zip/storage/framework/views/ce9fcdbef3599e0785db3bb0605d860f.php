

<?php $__env->startSection('content'); ?>
<h4 class="mb-3">Add Employee</h4>

<form method="POST" action="/employees/store">
  <?php echo csrf_field(); ?>
  <div class="row">
    <div class="col-md-6 mb-3">
      <input name="first_name" placeholder="First Name" class="form-control">
    </div>
    <div class="col-md-6 mb-3">
      <input name="last_name" placeholder="Last Name" class="form-control">
    </div>
    <div class="col-md-6 mb-3">
      <input name="email" placeholder="Email" class="form-control">
    </div>
    <div class="col-md-6 mb-3">
      <input name="joining_date" type="date" class="form-control">
    </div>
  <div class="col-md-6 mb-3">
  <label for="department_id" class="form-label">Select Department</label>
  <select name="department_id" id="department_id" class="form-control" required>
    <option value="">-- Select Department --</option>
    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($department->id); ?>"><?php echo e($department->dept_name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>

    <div class="col-md-6 mb-3">
      <input name="salary" placeholder="Salary" class="form-control">
    </div>
  </div>
  <button class="btn btn-success">Save</button>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Employee-App\employee-dashboard\resources\views/employees/add.blade.php ENDPATH**/ ?>